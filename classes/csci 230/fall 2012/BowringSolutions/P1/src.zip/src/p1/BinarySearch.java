/*
 * BinarySearch.java
 *
 * CSCI 230
 * Fall 2012
 * Dr. Bowring
 * 
 * Implements Binary Search Algorithm for integer arrays
 */
package p1;

/**
 *
 * @author James F. Bowring
 */
public class BinarySearch {

    /**
     * From textbook Data Structures and Algorithms, p. 25.
     *
     * Pre-conditions: searchArray is not null and has at least one element
     * searchArray contains searchValue.
     *
     * Post-condition: returned int is count of loop iterations to find
     * searchValue in searchArray.
     *
     * This implementation uses Java's default rounding down of i.5.
     *
     * @param searchArray
     * @param searchValue
     * @return
     */
    public static int binarySearchIterationCounter ( int[] searchArray, int searchValue ) {
        int iterationCount = 0;

        int low = 0;
        int high = (searchArray.length - 1);

        int index = (high + low) / 2;

        while ((searchValue != searchArray[index]) && (high != low)) {

            if ( searchValue < searchArray[index] ) {
                high = index - 1;
            } else {
                low = index + 1;
            }

            index = (high + low) / 2;

            iterationCount ++;
        }

        return iterationCount;
    }
}
