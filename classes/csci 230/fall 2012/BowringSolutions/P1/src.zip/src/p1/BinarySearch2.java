/*
 * BinarySearch2.java
 *
 * CSCI 230
 * Fall 2012
 * Dr. Bowring
 * 
 * Implements Binary Search Algorithm for integer arrays
 */
package p1;

/**
 *
 * @author James F. Bowring
 */
public class BinarySearch2 {

    /**
     * From textbook Data Structures and Algorithms, p. 25
     * Pre-conditions:  searchArray is not null and has at least one element
     *                  searchArray contains searchValue
     * Post-condition:  returned int is count of loop iterations to find searchValue in searchArray
     * 
     * This implementation uses rounding up of i.5 when i is even, rounding down otherwise to
     * balance the halving of the array when the length is even.
     * 
     * @param searchArray
     * @param searchValue
     * @return
     */
    public static int binarySearchIterationCounter ( int[] searchArray, int searchValue ) {
        int iterationCount = 0;

        int low = 0;
        int high = (searchArray.length - 1);

        int index = roundUpHalfEven((double)(high + low) / 2.0 );

        while ((searchValue != searchArray[index]) && (high != low)) {

            if ( searchValue < searchArray[index] ) {
                high = index - 1;
            } else {
                low = index + 1;
            }
            
            index = roundUpHalfEven((double)(high + low) / 2.0 );
            
            iterationCount ++;
        }

        return iterationCount;
    }
    
    /**
     * Rounds up to nearest integer when integer part is even, otherwise rounds down
     * @param n
     * @return 
     */
    private static int roundUpHalfEven(double n){
        int retVal;
        if (((int)Math.floor( n)) % 2 == 0){
            retVal = (int)Math.ceil( n);
        } else {
            retVal = (int)Math.floor( n);
        }
        
        return retVal;
    }
}
