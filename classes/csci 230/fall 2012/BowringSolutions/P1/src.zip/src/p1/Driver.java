/*
 * Driver.java
 * 
 * CSCI 230
 * Fall 2012
 * Dr. Bowring
 * 
 * Driver exercises the binary search algorithm to compare its average speed to its theoretical worst case speed.
 */
package p1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;

/**
 *
 * @author samuelbowring
 */
public class Driver {

    /**
     * @param args the command line arguments
     */
    public static void main ( String[] args ) {

        // array size hard coded
        int arraySize = 65000; //65536

        // build array of integers 1 ... arraySize
        int[] searchArray = new int[arraySize];
        for (int i = 0; i < searchArray.length; i ++) {
            searchArray[i] = i + 1;
        }

        Random generator = new Random();

        BufferedReader reader = new BufferedReader( new InputStreamReader( System.in ) );

        // Prompt the user 
        System.out.print( "Enter number of random searches: " );
        try {
            // exception thrown if not an integer,
            int numberOfRandomSearches = Integer.valueOf( reader.readLine() );

            int totalSearchIterations = 0;

            for (int i = 0; i < numberOfRandomSearches; i ++) {

                int randomIntegerToFind = 1 + generator.nextInt( arraySize );

                totalSearchIterations += BinarySearch.binarySearchIterationCounter( searchArray, randomIntegerToFind );
            }

            double averageIterationsPerSearch = (double) totalSearchIterations / (double) numberOfRandomSearches;

            System.out.println( "\nfor set of integers from 1 to " + arraySize );
            System.out.println( "\tsearch loop iterations to find 1 = \t" //
                    + BinarySearch.binarySearchIterationCounter( searchArray, 1 ) );
            System.out.println( "\tsearch loop iterations to find " + arraySize + " = \t" //
                    + BinarySearch.binarySearchIterationCounter( searchArray, arraySize ) );
            System.out.println( "\taverage random search loop iterations = " //
                    + averageIterationsPerSearch );
            System.out.println( "\t\t\tlog base 2 of " + arraySize + " = \t" //
                    + Math.log( arraySize ) / Math.log( 2 ) );

        } catch (IOException e) {
            System.out.println( "IO exception" );
        } catch (NumberFormatException e) {
            System.out.println( "Not an integer" );
        }
    }
}
