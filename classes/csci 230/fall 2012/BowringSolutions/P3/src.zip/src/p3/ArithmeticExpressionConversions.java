/*
 * ArithmeticExpressionConversions.java
 *
 * 
 * CSCI 230
 * Fall 2012
 * Dr. Bowring
 * 
 * Contains static methods for conversion of infix to postfix expressions and evauation of postfix expressions.
 * Error handling is left as an exercise for the student.
 */
package p3;

import java.util.ArrayList;

/**
 *
 * @author James F. Bowring
 */
public class ArithmeticExpressionConversions {

    static final ArrayList<String> operators = new ArrayList<String>();

    static {
        operators.add( "+" );
        operators.add( "-" );
        operators.add( "*" );
        operators.add( "/" );
    }

    /**
     * Pre-conditions: infixExpression is a well-formed infix expression with parentheses
     * defining the precedence of operations, with a single space between every 
     * parenthesis, operator, and/or operand,
     * with integer operands, and these common operators: +,-,*,/
     * 
     * Post-condition: returns a String postfixed representation of the infixExpression
     * consisting of integers and operands separated by single spaces.
     * 
     * @param infixExpression
     * @return 
     */
    public static String convertInfixToPostfix ( String infixExpression ) {
        String postFixExpression = "";

        String[] infixElements = infixExpression.split( " " );

        StringStack workList = new StringStack();

        for (int i = 0; i < infixElements.length; i ++) {

            String infixElement = infixElements[i].trim();

            if ( infixElement.compareTo( "(" ) == 0 ) {
                // do nothing
                
            } else if ( infixElement.compareTo( ")" ) == 0 ) {
                if(!workList.empty()){
                    postFixExpression = postFixExpression + " " + workList.pop();
                }
                
            } else if ( operators.contains( infixElement ) ) {
                workList.push( infixElement);
                
            } else {
                postFixExpression = postFixExpression + " " + infixElement;
            }
        }

        // retrieve remaining operands
        while (  ! workList.empty() ) {
            postFixExpression = postFixExpression + " " + workList.pop();
        }

        return postFixExpression;
    }

    /**
     * Pre-condition: postfixExpression is a well-formed postfixed representation
     * consisting of integers and operands separated by single spaces.
     * 
     * Post-condition: returns an int representing the integer evaluation of 
     * postfixExpression.
     * 
     * @param postfixExpression
     * @return 
     */
    public static int evaluatePostfixExpression ( String postfixExpression ) {
        int evaluation = 0;

        String[] postfixElements = postfixExpression.split( " " );

        StringStack workList = new StringStack();

        // if operator encountered, assume at least two operands on stack
        for (int i = 0; i < postfixElements.length; i ++) {
            String postfixElement = postfixElements[i].trim();

            if ( operators.contains( postfixElement ) ) {
                int val1 = Integer.valueOf( workList.pop() );
                int val2 = Integer.valueOf( workList.pop() );

                if ( postfixElement.compareTo( "+" ) == 0 ) {
                    evaluation = val2 + val1;

                } else if ( postfixElement.compareTo( "-" ) == 0 ) {
                    evaluation = val2 - val1;
                    
                } else if ( postfixElement.compareTo( "*" ) == 0 ) {
                    evaluation = val2 * val1;
                    
                } else {
                    evaluation = val2 / val1;
                }
                
                workList.push( String.valueOf( evaluation) );
                
            } else {
                // push operand 
                if ( postfixElement.length() > 0 ) {
                    workList.push( postfixElements[i] );
                }
            }

        }
        
        // capture singleton - if only one int on stack, it is expression
        if (!workList.empty()){
            evaluation = Integer.valueOf( workList.pop() );
        }

        return evaluation;
    }
}
