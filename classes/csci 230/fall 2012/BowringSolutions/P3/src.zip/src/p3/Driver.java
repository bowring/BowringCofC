/*
 * Driver.java
 * 
 * CSCI 230
 * Fall 2012
 * Dr. Bowring
 * 
 * Driver exercises the infixed conversion to postfixed and then evaluates postfixed expression.
 * Error handling is left as an exercise for the student.
 */
package p3;

/**
 *
 * @author samuelbowring
 */
public class Driver {

    /**
     * @param args the command line arguments
     */
    public static void main ( String[] args ) {
        
        // Complete implementation of the driver is left as an exercise for the student.
        
        String infixExpression = "( ( 4 * 4 ) - ( ( 4 * 3 ) * 5 ) ) / ( 2 * 5 )";
        infixExpression = "( ( (  ) ) )";
        
        System.out.println("Infix expression: "//
                + infixExpression);
        
        String postfixExpression = ArithmeticExpressionConversions.convertInfixToPostfix(infixExpression);
        System.out.println("Postfix expression: " //
                + postfixExpression);
        
        System.out.println("Integer evaluation: " + //
                ArithmeticExpressionConversions.evaluatePostfixExpression(//
                postfixExpression));
    }
}
