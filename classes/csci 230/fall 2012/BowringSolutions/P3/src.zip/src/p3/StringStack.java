/*
 * StringStack.java
 * 
 * CSCI 230
 * Fall 2012
 * Dr. Bowring
 * 
 * StringStack implements a simple stack of String objects.
 * Error handling is left as an exercise for the student.
 */
package p3;

/**
 *
 * @author samuelbowring
 */
public class StringStack {
    
    private String[] data;
    private int top;
    private int size;

    public StringStack () {
        this(100);
    }

    public StringStack ( int size ) {
        this.data = new String[size];
        this.top = -1;
        this.size = size;
    }
    
    public boolean push(String element){
        boolean success = false;
        if (top < (size - 1)){
            top++;
            data[top] = element;
            success = true;
        }
        
        return success;
    }
    
    public String pop(){
        String popped = null;

        if (top > -1){
            int topLocation = top;
            top --;
            popped = data[topLocation];
        }
        
        return popped;
    }
    
    public boolean empty(){
        return top == -1;
    }
    
    public void showAll(){
        for (int i = top; i >=0; i --){
            System.out.println(data[i]);
        }
    }
}
