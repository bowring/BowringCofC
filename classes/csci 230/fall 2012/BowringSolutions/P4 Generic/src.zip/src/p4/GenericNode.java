/*
 * GenericNode.java
 *
 * CSCI 230
 * Fall 2012
 * Dr. Bowring
 * 
 * Provides a generic node for use with GenericStackSLL class.
 */

package p4;

/**
 *
 * @author James F. Bowring
 */
public class GenericNode<T> {

    private T contents;
    private GenericNode next;

    public GenericNode () {
        this.contents = null;
        this.next = null;
    }

    /**
     * @return the contents
     */
    public T getContents () {
        return contents;
    }

    /**
     * @param contents the contents to set
     */
    public void setContents ( T contents ) {
        this.contents = contents;
    }

    /**
     * @return the next
     */
    public GenericNode getNext () {
        return next;
    }

    /**
     * @param next the next to set
     */
    public void setNext ( GenericNode next ) {
        this.next = next;
    }

    public String showContents(){
        return contents.toString();
    }
    
}
