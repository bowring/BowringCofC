/*
 * GenericStack.java
 * 
 * CSCI 230
 * Fall 2012
 * Dr. Bowring
 * 
 * GenericStack implements a simple stack of String objects.
 * Error handling is left as an exercise for the student.
 */
package p4;

/**
 *
 * @author samuelbowring
 */
public class GenericStack<T> implements GenericStackInterface<T> {
    
    private T[] data;
    private int top;
    private int size;

    public GenericStack () {
        this(100);
    }

    public GenericStack ( int size ) {
        this.data = (T[])new Object[size];
        this.top = -1;
        this.size = size;
    }
    
    @Override
    public boolean push(T element){
        boolean success = false;
        if (top < (size - 1)){
            top++;
            data[top] = element;
            success = true;
        }
        
        return success;
    }
    
    @Override
    public T pop(){
        T popped = null;

        if (top > -1){
            int topLocation = top;
            top --;
            popped = data[topLocation];
        }
        
        return popped;
    }
    
    @Override
    public boolean empty(){
        return top == -1;
    }
    
    @Override
    public void showAll(){
        for (int i = top; i >=0; i --){
            System.out.println(data[i].toString());
        }
    }
}
