/*
 * GenericStackInterface.java
 * 
 * CSCI 230
 * Fall 2012
 * Dr. Bowring
 * 
 * GenericStackInterface specifies a Stack using any generic object class. 
 * Error handling is left as an exercise for the student.
 */
package p4;

/**
 *
 * @author James F. Bowring
 */
public interface GenericStackInterface<T> {

    boolean empty ();

    T pop ();

    boolean push ( T element );

    void showAll ();
    
}
