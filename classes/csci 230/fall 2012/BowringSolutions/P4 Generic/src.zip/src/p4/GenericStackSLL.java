/*
 * GenericStackSLL.java
 * 
 * CSCI 230
 * Fall 2012
 * Dr. Bowring
 * 
 * StringStack implements a simple stack of String objects.
 * Error handling is left as an exercise for the student.
 */
package p4;

/**
 *
 * @author samuelbowring
 */
public class GenericStackSLL<T> implements GenericStackInterface<T> {

    private GenericNode header;

    public GenericStackSLL () {
        header = new GenericNode();
    }

    @Override
    public boolean push ( T element ) {
        boolean success = false;

        GenericNode node = new GenericNode();
        
        if ( node != null ) {
            node.setNext( header.getNext() );
            header.setNext( node );
            node.setContents( element );
            success = true;
        }

        return success;
    }

    @Override
    public T pop () {
        T poppedContents = null;
        
        GenericNode popped = header.getNext();
        if (popped != null){
            poppedContents = (T)popped.getContents();
            header.setNext( popped.getNext());
        }

        return poppedContents;
    }

    @Override
    public boolean empty () {
        return header.getNext() == null;
    }

    @Override
    public void showAll () {
        
        GenericNode pNode = header.getNext();
        
        while (pNode != null){
            System.out.println( pNode.showContents() );
            pNode = pNode.getNext();
        }
    }
}
