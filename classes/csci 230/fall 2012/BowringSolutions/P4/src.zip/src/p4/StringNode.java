/*
 * StringNode.java
 *
 * CSCI 230
 * Fall 2012
 * Dr. Bowring
 * 
 * Provides a Node with String contents for StringStackSLL.
 */

package p4;

/**
 *
 * @author James F. Bowring
 */
public class StringNode {

    private String contents;
    private StringNode next;

    public StringNode () {
        this.contents = null;
        this.next = null;
    }

    /**
     * @return the contents
     */
    public String getContents () {
        return contents;
    }

    /**
     * @param contents the contents to set
     */
    public void setContents ( String contents ) {
        this.contents = contents;
    }

    /**
     * @return the next
     */
    public StringNode getNext () {
        return next;
    }

    /**
     * @param next the next to set
     */
    public void setNext ( StringNode next ) {
        this.next = next;
    }

    
    
}
