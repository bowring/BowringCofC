/*
 * StringStackInterface.java
 * 
 * CSCI 230
 * Fall 2012
 * Dr. Bowring
 * 
 * StringStackInterface specifies a Stack for String objects.
 * Error handling is left as an exercise for the student.
 */
package p4;

/**
 *
 * @author James F. Bowring
 */
public interface StringStackInterface {

    boolean empty ();

    String pop ();

    boolean push ( String element );

    void showAll ();
    
}
