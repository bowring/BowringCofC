/*
 * StringStackSLL.java
 * 
 * CSCI 230
 * Fall 2012
 * Dr. Bowring
 * 
 * StringStackSLL implements a simple stack of String objects as a singly-linked list.
 * Error handling is left as an exercise for the student.
 */
package p4;

/**
 *
 * @author samuelbowring
 */
public class StringStackSLL implements StringStackInterface {

    private StringNode header;

    public StringStackSLL () {
        header = new StringNode();
    }

    @Override
    public boolean push ( String element ) {
        boolean success = false;

        StringNode node = new StringNode();
        
        if ( node != null ) {
            node.setNext( header.getNext() );
            header.setNext( node );
            node.setContents( element );
            success = true;
        }

        return success;
    }

    @Override
    public String pop () {
        String poppedContents = null;
        
        StringNode popped = header.getNext();
        if (popped != null){
            poppedContents = popped.getContents();
            header.setNext( popped.getNext());
        }

        return poppedContents;
    }

    @Override
    public boolean empty () {
        return header.getNext() == null;
    }

    @Override
    public void showAll () {
        
        StringNode pNode = header.getNext();
        
        while (pNode != null){
            System.out.println( pNode.getContents() );
            pNode = pNode.getNext();
        }
    }
}
