/*
 * Driver.java
 * 
 * CSCI 230
 * Fall 2012
 * Dr. Bowring
 * 
 * Driver exercises Queue implemented as double-ended singly link list.
 * Error handling is left as an exercise for the student.
 */
package p5;

/**
 *
 * @author James F. Bowring
 */
public class Driver {

    /**
     * @param args the command line arguments
     */
    public static void main ( String[] args ) {
         GenericQueueInterface<String> myQueue = new GenericQueueDELL<String>();
         
         myQueue.enqueue( "A");
         myQueue.enqueue( "little");
         myQueue.enqueue( "queue");
         
         System.out.println(myQueue.dequeue());
         System.out.println(myQueue.dequeue());
         System.out.println(myQueue.dequeue());
    }
}
