/*
 * GenericNode.java
 *
 * CSCI 230
 * Fall 2012
 * Dr. Bowring
 * 
 * Provides a generic node for use with GenericStackSLL class.
 */

package p5;

/**
 *
 * @author James F. Bowring
 */
public class GenericNode<T> {

    private T contents;
    private GenericNode next;
    private GenericNode rear;

    public GenericNode () {
        this.contents = null;
        this.next = null;
        this.rear = null;
    }

    /**
     * @return the contents
     */
    public T getContents () {
        return contents;
    }

    /**
     * @param contents the contents to set
     */
    public void setContents ( T contents ) {
        this.contents = contents;
    }

    /**
     * @return the next
     */
    public GenericNode getNext () {
        return next;
    }

    /**
     * @param next the next to set
     */
    public void setNext ( GenericNode next ) {
        this.next = next;
    }

    public String showContents(){
        return contents.toString();
    }

    /**
     * @return the rear
     */
    public GenericNode getRear () {
        return rear;
    }

    /**
     * @param rear the rear to set
     */
    public void setRear ( GenericNode rear ) {
        this.rear = rear;
    }
    
}
