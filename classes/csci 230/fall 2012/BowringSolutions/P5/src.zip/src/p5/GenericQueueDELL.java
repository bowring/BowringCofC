/*
 * GenericQueueDELL.java
 * 
 * CSCI 230
 * Fall 2012
 * Dr. Bowring
 */
package p5;

/**
 *
 * @author James F. Bowring
 */
public class GenericQueueDELL<T> implements GenericQueueInterface<T> {

    private GenericNode header;

    public GenericQueueDELL () {
        header = new GenericNode();
    }

    @Override
    public boolean enqueue ( T contents ) {
        boolean success = false;

        GenericNode node = new GenericNode();

        if ( node != null ) {
            node.setContents( contents );
            
            if ( header.getNext() == null ) {
                header.setNext( node );
                header.setRear( node );
            } else {
                header.getRear().setNext( node );
                header.setRear( node );
            }

            success = true;
        }

        return success;
    }

    @Override
    public T dequeue () {
        T dequeuedContents = null;

        GenericNode dequeued = header.getNext();
        if ( dequeued != null ) {
            dequeuedContents = (T) dequeued.getContents();
            header.setNext( dequeued.getNext());
        }


        return dequeuedContents;
    }
}
