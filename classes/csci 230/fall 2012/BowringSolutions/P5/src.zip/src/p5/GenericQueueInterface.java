/*
 * GenericQueueInterface.java
 * 
 * CSCI 230
 * Fall 2012
 * Dr. Bowring
 */

package p5;

/**
 *
 * @author James F. Bowring
 */
public interface GenericQueueInterface <T>{
    
    boolean enqueue(T element);
    
    T dequeue();

}
