/*
 * Driver.java
 * 
 * CSCI 230
 * Fall 2012
 * Dr. Bowring
 * 
 * Driver runs the static method RecursionExercisesII.produceRoute().
 * Pre- and Post-conditions are left as an exercise for the student.
 * Error handling is left as an exercise for the student.
 */
package p8;

/**
 *
 * @author James F Bowring
 */
public class Driver {

    /**
     * @param args the command line arguments
     */
    public static void main ( String[] args ) {
        RecursionExercisesII.produceRoute( 10 );
    }
}
