/*
 * RecursionExercisesII.java
 * 
 * CSCI 230
 * Fall 2012
 * Dr. Bowring
 * 
 * Programming exercise 6.24.
 * Pre- and Post-conditions are left as an exercise for the student.
 * Error handling is left as an exercise for the student.
 */

package p8;


import javax.swing.JFrame;


/**
 *
 * @author James F. Bowring
 */
public class RecursionExercisesII {

    private final static int[][] routeMap = //
            {
        {0, 3, 5, 6, 1, 2, 7, 1, 9, 4},
        {8, 8, 3, 6, 5, 8, 3, 9, 1, 5},
        {6, 4, 3, 8, 7, 1, 2, 4, 7, 4},
        {5, 3, 8, 4, 2, 6, 7, 9, 3, 5},
        {1, 6, 3, 2, 1, 4, 3, 3, 7, 9},
        {7, 3, 7, 4, 4, 1, 5, 9, 9, 4},
        {1, 8, 6, 6, 8, 4, 8, 3, 8, 2},
        {4, 8, 1, 9, 7, 9, 2, 3, 5, 4},
        {9, 1, 4, 7, 3, 6, 8, 6, 1, 4},
        {6, 4, 7, 4, 8, 3, 6, 7, 2, 4}
    };
    private static int[] colChoices = {-1, 0, 1};
    private static int[] currentMinRoute = new int[routeMap.length];
    private static int[] savedMinRoute = new int[routeMap.length];
    private static int savedMinToll = 10 * routeMap.length;
    private static int currentMinToll = 0;
    private static JFrame myMapBoard;

    private static int nextChoiceColumn ( int choiceNumber, int fromCol ) {
        return fromCol + colChoices[choiceNumber];
    }

    private static int nextChoiceRow ( int fromRow ) {
        return fromRow + 1;
    }

    private static boolean thisDecisionChoiceIsValid ( int row, int column ) {
        return (row >= 0 && row < routeMap.length
                && column >= 0 && column < routeMap[0].length
                && (currentMinToll + routeMap[row][column]) < savedMinToll);
    }

    private static void recordThisDecisionChoice ( int row, int column ) {
        ((TollsMapBoard)myMapBoard).markCell(row, column);
        currentMinToll = currentMinToll + routeMap[row][column];
        currentMinRoute[row] = column;
    }

    private static void unrecordThisDecisionChoice ( int row ) {
        ((TollsMapBoard)myMapBoard).unMarkCell( row, currentMinRoute[row]);
        currentMinToll = currentMinToll - routeMap[row][currentMinRoute[row]];
        currentMinRoute[row] = 0;
    }

    private static boolean goalHasBeenReached ( int row ) {
        return (row == routeMap.length - 1);
    }

    private static void makeNextDecision ( int fromRow, int fromCol ) {

        int choiceNumber = 0;
        int row = nextChoiceRow( fromRow );

        while (choiceNumber < colChoices.length) {

            int col = nextChoiceColumn( choiceNumber, fromCol );

            if ( thisDecisionChoiceIsValid( row, col ) ) {
                recordThisDecisionChoice( row, col );

                if ( goalHasBeenReached( row ) ) {
                    if ( currentMinToll < savedMinToll ) {
                        ((TollsMapBoard)myMapBoard).unMarkPath( savedMinRoute );
                        
                        System.arraycopy( currentMinRoute, 0, savedMinRoute, 0, currentMinRoute.length );
                        ((TollsMapBoard)myMapBoard).markPath( savedMinRoute );
                        
                        savedMinToll = currentMinToll;
                    }

                } else // make next decision
                {
                    makeNextDecision( row, col );
                }
                
                unrecordThisDecisionChoice( row );
            }// end if

            choiceNumber = choiceNumber + 1;
        }// end while

    }

    public static void produceRoute(int pause){
        // set up visualization with map data
        myMapBoard = new TollsMapBoard(routeMap.length, 50, pause);
        for (int i = 0; i < routeMap.length; i ++){
            for (int j = 0; j < routeMap[i].length; j ++){
                ((TollsMapBoard)myMapBoard).setCell( i, j, routeMap[i][j]);
            }
        }
        myMapBoard.setVisible(true);
        
        // execute solution
        for (int startingCol = 0; startingCol < savedMinRoute.length; startingCol ++) {
            currentMinRoute[0] = startingCol;
            currentMinToll = routeMap[0][startingCol];
            makeNextDecision( 0, startingCol );
        }

        //report solution
        System.out.print( savedMinToll + " route = " );
        for (int i = 0; i < savedMinRoute.length; i ++) {
            System.out.print( "\t" + savedMinRoute[i] );
        }
        System.out.println();
    }
    
}
